import pygame as p, sys
p.init()
s = p.display.set_mode((800, 600))
q, b, a = p.K_DOWN, p.Rect(400, 300, 20, 20), [p.Rect(10, 250, 10, 100), p.Rect(780, 250, 10, 100)]
sx, sy, sp = 6, 6, 8
def dr(): s.fill((0, 0, 0)); [p.draw.rect(s, (255, 255, 255), i) for i in a]; p.draw.ellipse(s, (255, 255, 255), b); p.display.flip()
while 1:
    for e in p.event.get():
        if e.type == p.QUIT: p.quit(); sys.exit()
    k = p.key.get_pressed()
    if k[p.K_w]: a[0].move_ip(0, -sp)
    if k[p.K_s]: a[0].move_ip(0, sp)
    if k[p.K_UP]: a[1].move_ip(0, -sp)
    if k[q]: a[1].move_ip(0, sp)
    for i in a:
        if i.top < 0: i.y = 0
        if i.bottom > 600: i.y = 500
    b.move_ip(sx, sy)
    if b.top < 0 or b.bottom > 600: sy = -sy
    if b.left < 0 or b.right > 800: b.x, b.y = 400, 300
    if b.colliderect(a[0]) or b.colliderect(a[1]): sx = -sx
    dr(); p.time.delay(16)